package com.csci.grammar;

public class ListDef extends java.util.LinkedList<Def> { }
