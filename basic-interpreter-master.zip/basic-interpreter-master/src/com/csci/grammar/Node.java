package com.csci.grammar;

import com.csci.visitor.Visitable;

abstract class Node implements Visitable { }
