package com.csci.grammar;

public class ListStm extends java.util.LinkedList<Stm> { }
