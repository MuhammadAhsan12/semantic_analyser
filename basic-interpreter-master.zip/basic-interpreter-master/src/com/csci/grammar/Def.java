package com.csci.grammar;

public abstract class Def extends Node { }
