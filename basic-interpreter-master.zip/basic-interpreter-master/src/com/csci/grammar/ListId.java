package com.csci.grammar;

public class ListId extends java.util.LinkedList<String> { }
