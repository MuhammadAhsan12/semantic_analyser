package com.csci.grammar;

public class ListArg extends java.util.LinkedList<Arg> { }
